package Controller;

public class Endereco {
    public String cidade;
    public String rua;
    public String uf;
    public String pais;
    public String cep;

    public String getRua() {return rua;}
    public void setRua(String rua) {this.rua = rua;}

    public String getUf() {return uf;}
    public void setUf(String uf) {this.uf = uf;}

    public String getCidade() {return cidade;}
    public void setCidade(String cidade) {this.cidade = cidade;}

    public String getPais() {return pais;}
    public void setPais(String pais) {this.pais = pais;}

    public String getCep() {return cep;}
    public void setCep(String cep) {this.cep = cep;}


    @Override
    public String toString() {
        return "Endereco{" +
                "rua='" + rua + '\'' +
                ", cidade='" + cidade + '\'' +
                ", uf='" + uf + '\'' +
                ", cep='" + cep + '\'' +
                ", pais='" + pais + '\'' +
                '}';
    }
}
