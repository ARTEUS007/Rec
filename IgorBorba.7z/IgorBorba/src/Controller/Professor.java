package Controller;

public class Professor {
    public int salario;

    @Override
    public String toString() {
        return "Professor{" +
                "salario=" + salario +
                '}';
    }
}
