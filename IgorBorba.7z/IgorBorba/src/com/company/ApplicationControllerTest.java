package com.company;

import static org.junit.jupiter.api.Assertions.*;

class ApplicationControllerTest {
    @Test
    void contextLoads() {}
}