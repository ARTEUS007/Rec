package com.company;

public class Main {

    @Override
    public String toString() {
        return "Main{}";
    }

    public static void main(String[] args) {
	String nome;
    double preco;
    }
}
